const lookupBtn = document.querySelector(".lookup-btn");
const ipDisplay = document.querySelector(".ip-display");
const locationDisplay = document.querySelector(".location-display");
const geoDisplay = document.querySelector(".geo-display");
const loader = document.querySelector(".loader-container");
const details  = document.querySelector(".details");
lookupBtn.addEventListener("click", () => {
    loader.style.display = "flex";
    details.style.display = "none";
    axios.get("https://ipapi.co/json/").then((Response)=> {
        loader.style.display = "none";
        details.style.display = "block";
   ipDisplay.textContent = `Ip: ${Response.data.ip}`;
  locationDisplay.textContent = `Location: ${Response.data.city}, ${Response.data.region}, ${Response.data.country_name}`;
   geoDisplay.textContent = `Geographical Location: ${Response.data.latitude}, ${Response.data.longitude}`;
});

});
